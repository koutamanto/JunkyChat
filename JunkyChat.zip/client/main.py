import sys, json, requests
from datetime import datetime
from PyQt5 import QtWidgets, QtCore
from JunkyChat import Ui_Dialog
from PyQt5.QtCore import QUrl

user_name = "ゲスト"#1.ここのユーザー名を変更する
#2.「py main.py」で起動する 3.メッセージを入力する 4.話す
#エラーが出たら「pip install requests」のように「pip install エラーに表示されているモジュール名」でインストールする

class Test(QtWidgets.QMainWindow):
  def __init__(self,parent=None):
    super(Test, self).__init__(parent)
    self.ui = Ui_Dialog()
    self.ui.setupUi(self)
    self.ui.Send.clicked.connect(self.send)
    timer = QtCore.QTimer()
    timer.timeout.connect(self.view)
    timer.start(3000)
  def send(self):
    msg = self.ui.MessageForm.toPlainText()
    print(msg)
    send_date = datetime.now()
    data = json.dumps({"msg":"["+str(send_date)+"] "+"["+user_name+":] "+msg})
    res = requests.post('https://junkychat.herokuapp.com/send',data=data)
    self.view()
  def view(self):
    msg_list = []
    ret_msg = ""
    msgs = requests.get("https://junkychat.herokuapp.com/view").text
    msgs = eval(msgs)["datas"]
    print(msgs)
    for msg in msgs:
      print(msg)
      ret_msg = ret_msg + "\n" + msg["msg"]
    print(ret_msg)
    self.ui.MessageLogs.setText(ret_msg)
if __name__ == '__main__':
  app = QtWidgets.QApplication(sys.argv)
  window = Test()
  window.show()
  sys.exit(app.exec_())